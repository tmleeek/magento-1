var config = {
    map: {
        '*': {
            ticketEditPage:   'Mirasvit_Helpdesk/js/ticket-edit-page'
        }
    }
};
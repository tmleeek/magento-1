<?php

/**
 * @Author: Ngo Quang Cuong <bestearnmoney87@gmail.com>
 * @Creation time: 2017-06-12 12:39:35
 * @Last modified time: 2017-06-12 12:39:43
 * @link: http://www.giaphugroup.com
 *
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'PHPCuong_Checkout',
    __DIR__
);

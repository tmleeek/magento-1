<?php

/**
 * @Author: Ngo Quang Cuong
 * @Date:   2017-06-29 09:22:47
 * @Last Modified by:   nquangcuong
 * @Last Modified time: 2017-06-29 09:22:54
 * @website: http://giaphugroup.com
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'PHPCuong_CustomerPoints',
    __DIR__
);

# magento2-customer-points
Magento 2 Customer Points, Reward Points
# See the video about this tutorial
https://www.youtube.com/watch?v=Tl78eOqYbxQ

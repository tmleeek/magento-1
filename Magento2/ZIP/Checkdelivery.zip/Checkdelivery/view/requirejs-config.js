// var config = {
//   paths:{
//     "jquery.flexslider":"Bluethink_KnowledgeBase/js/flexslider",
//   },
//   shim:{
//   	'jquery.flexslider':{
//         'deps':['jquery']
//     }
//   }
// };

var config = {
    map: {
        '*': {
            giftMessage:    'Bluethink_Checkdelivery/js/flexslider'
        }
    }
};



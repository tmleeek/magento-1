<?php
/**
 * Copyright © 2015 Bluethink . All rights reserved.
 */
namespace Bluethink\Checkdelivery\Block\Index;
use Bluethink\Checkdelivery\Block\BaseBlock;
class Index extends BaseBlock
{
	public $hello='Hello World';
	
}

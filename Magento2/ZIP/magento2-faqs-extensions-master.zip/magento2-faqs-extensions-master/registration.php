<?php

/**
 *
 * @Author              Ngo Quang Cuong <bestearnmoney87@gmail.com>
 * @Date                2016-12-15 20:25:23
 * @Last modified by:   nquangcuong
 * @Last Modified time: 2016-12-15 20:25:43
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'PHPCuong_Faq',
    __DIR__
);

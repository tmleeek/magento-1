# magento2-knockoutjs
Using Knockout JS in Magento 2 to Decrease and the Increase Qty of the product on the product detail page.

## Snapshot
![ScreenShot](https://raw.githubusercontent.com/php-cuong/magento2-knockoutjs/master/Snapshot/Increase-qty.png)

## See the video how I can create this extension
https://www.youtube.com/watch?v=3mGfCqLvSvA

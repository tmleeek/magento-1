<?php

/**
 * @Author: Ngo Quang Cuong
 * @Date:   2017-07-11 14:35:21
 * @Last Modified by:   nquangcuong
 * @Last Modified time: 2017-07-11 14:35:41
 * @website: http://giaphugroup.com
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'PHPCuong_ProductQty',
    __DIR__
);

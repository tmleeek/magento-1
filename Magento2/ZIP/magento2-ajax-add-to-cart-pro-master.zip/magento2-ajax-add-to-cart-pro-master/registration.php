<?php

/**
 * @Author: Ngo Quang Cuong
 * @Date:   2017-07-25 17:42:29
 * @Last Modified by:   nquangcuong
 * @Last Modified time: 2017-07-25 17:42:37
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'PHPCuong_AjaxAddToCart',
    __DIR__
);

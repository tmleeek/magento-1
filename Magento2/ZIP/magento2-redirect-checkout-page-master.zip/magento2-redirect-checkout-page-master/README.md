# magento2-redirect-checkout-page
Using the plugin in Magento 2: 
- To redirect the customer to the checkout page when adding a product to the cart. 
- To change the image of all the product on the checkout page. At the current time, it is the image of a product.

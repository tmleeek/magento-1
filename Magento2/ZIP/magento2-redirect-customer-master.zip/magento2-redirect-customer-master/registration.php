<?php

/**
 *
 * @Author              Ngo Quang Cuong <bestearnmoney87@gmail.com>
 * @Date                2017-01-11 05:00:57
 * @Last modified by:   nquangcuong
 * @Last Modified time: 2017-01-11 05:01:25
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'PHPCuong_RedirectCustomer',
    __DIR__
);

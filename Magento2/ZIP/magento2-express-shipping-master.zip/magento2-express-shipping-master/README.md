# magento2-express-shipping
How to create a new shipping method in Magento 2

# See the video How to create a new shipping method in Magento 2 here
https://www.youtube.com/watch?v=0CzMIMyxaZQ

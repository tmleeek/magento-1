# php-ajax-html-contact-form-attachment
How to create a simple HTML contact form with Ajax, PHP and an Attachment

# see the video about this tutorial here
https://www.youtube.com/watch?v=izVfl2YCsj0

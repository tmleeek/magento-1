<?php
 /**
  * Webkul_Stripe Module Registration
  *
  * @category Webkul
  * @package  Webkul_Stripe
  * @author   Webkul Software Private Limited
  */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Webkul_Stripe',
    __DIR__
);

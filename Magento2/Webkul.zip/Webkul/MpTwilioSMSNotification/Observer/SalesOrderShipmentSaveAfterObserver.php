<?php
/**
 * @category   Webkul
 * @package    Webkul_MpTwilioSMSNotification
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) 2010-2017 Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */ 
namespace Webkul\MpTwilioSMSNotification\Observer;

use Magento\Framework\Event\ObserverInterface;
use Webkul\MpTwilioSMSNotification\Helper\Data;
use Webkul\Marketplace\Helper\Data as MpHelper;
use Magento\Framework\Message\ManagerInterface;
use Magento\Catalog\Model\Product;
use Magento\Customer\Model\Customer;
use Webkul\Marketplace\Model\Orders;

/**
 * Webkul MpTwilioSMSNotification SalesOrderShipmentSaveAfterObserver Observer.
 */
class SalesOrderShipmentSaveAfterObserver implements ObserverInterface
{

    /**
     * @var Webkul\MpTwilioSMSNotification\Helper\Data
     */
    protected $_helperData;
    /**
     * @var Webkul\Marketplace\Helper\Data
     */
    protected $_helperMarketplace;
    /**
     * @var Magento\Framework\Message\ManagerInterface
     */
    protected $_messageManager;
    /**
     * @var Magento\Catalog\Model\Product
     */
    protected $_productModel;
    /**
     * @var Magento\Customer\Model\Customer
     */
    protected $_customerModel;
    /**
     * @var Webkul\Marketplace\Model\Orders
     */
    protected $_orderModelMp;

    /**
     * @param Data             $helperData
     * @param Customer         $customerModel
     * @param Orders           $orderModelMp
     * @param MpHelper         $helperMarketplace
     * @param Product          $productModel
     * @param ManagerInterface $messageManager
     */
    public function __construct(
        Data $helperData,
        Customer $customerModel,
        Orders $orderModelMp,
        MpHelper $helperMarketplace,
        Product $productModel,
        ManagerInterface $messageManager
    ) {
        $this->_orderModelMp = $orderModelMp;
        $this->_customerModel = $customerModel;
        $this->_productModel = $productModel;
        $this->_messageManager = $messageManager;
        $this->_helperMarketplace = $helperMarketplace;
        $this->_helperData = $helperData;
    }

    /**
     * sales_order_shipment_save_after event handler.
     *
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        if ($this->_helperData->getTwilioStatus()) {
            $accountSid = $this->_helperData->getTwilioAccountSid();
            $authToken = $this->_helperData->getTwilioAuthToken();
            $twilioPhoneNumber = $this->_helperData
                                ->getTwilioPhoneNumber();
            $shipment = $observer->getEvent()->getShipment();
            $order = $shipment->getOrder();
            $fromNumber = $twilioPhoneNumber;
            //get all of the order items:
            $orderId="";
            $qtyShipped="";
            $items = $order->getAllItems();
            $client = new \Twilio\Rest\Client($accountSid, $authToken);
            foreach ($items as $item) {
                $orderId = $item->getOrderId();
                $qtyShipped = $item->getQtyShipped();
                $sellerOrder = $this->_orderModelMp
                                ->getCollection()
                                ->addFieldToFilter(
                                    'order_id',
                                    $orderId
                                );
                $sellerInformation = $this->_sendMSGtoSeller($sellerOrder);
                if (!empty($sellerInformation)) {
                    $content = __(
                        "Hi %1, the Order has been Shipped with Qty %2 , please check your mail for more details at %3",
                        $sellerInformation['firstName'],
                        $qtyShipped,
                        $sellerInformation['email']
                    );
                    try {
                        $client->account->messages->create(
                            $sellerInformation['toNumber'],

                            [
                                'from' => $fromNumber, 
                                'body' => $content
                            ]
                        );
                    } catch (\Exception $e) {
                        $this->_messageManager
                                ->addError($e->getMessage());
                    }
                }
            }
        }
    }

    /**
     * return seller information
     * @param  object $sellerOrderCollection
     * @return array
     */
    private function _sendMSGtoSeller($sellerOrderCollection)
    {
        $sellerInformation =[];
        foreach ($sellerOrderCollection as $info) {
            if ($info['seller_id']!=0) {
                $userData = $this->_helperData
                        ->getCustomer($info['seller_id']);
                $mpSellerCollection = $this->_helperMarketplace
                                        ->getSellerDataBySellerId(
                                            $info->getSellerId()
                                        );
                $sellerInformation = $this->_getSellerInformation(
                    $mpSellerCollection,
                    $userData
                );
            }
            return $sellerInformation;
        }
    }

    /**
     * get seller information related to order item
     * @param  object $mpSellerCollection
     * @param  object $userData
     * @return array
     */
    private function _getSellerInformation(
        $mpSellerCollection,
        $userData
    ) {
        foreach ($mpSellerCollection as $sellerData) {
            $sellerInfo['firstName'] = $userData->getFirstname();
            $sellerInfo['toNumber'] = str_replace(
                " ",
                "",
                $sellerData->getContactNumber()
            );
            $sellerInfo['email'] = $userData->getEmail();
            return $sellerInfo;
        }
    }
}

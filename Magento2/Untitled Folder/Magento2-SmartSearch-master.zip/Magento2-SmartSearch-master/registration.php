<?php
/*
|--------------------------------------------------------------------------
|   registration
|--------------------------------------------------------------------------
|
|   Registration file for SmartSearch Module
|
|   @author Sebwite
|   @date 23 november 2015
|   @time 16:54
*/

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Sebwite_SmartSearch',
    __DIR__
);
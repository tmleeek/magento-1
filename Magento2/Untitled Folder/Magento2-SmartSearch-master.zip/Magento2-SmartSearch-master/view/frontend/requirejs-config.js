var config = {
    map: {
        '*': {
            'quickSearch':'Sebwite_SmartSearch/form-mini'
        }
    }
};
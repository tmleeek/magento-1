define([
    'underscore',
    'ko',
    'jquery',
    'Mirasvit_Helpdesk/js/lib/jquery.MultiFile'
], function (_, ko, Component, Collapsible, $) {
    'use strict';
});

var config = {
    map: {
        '*': {
            helpdeskCustomerAccount:   'Mirasvit_Helpdesk/js/customer-account'
        }
    }
};